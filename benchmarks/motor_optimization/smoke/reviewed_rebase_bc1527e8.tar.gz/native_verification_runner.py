"""Sequential, external verification runner; refuses a live/incomplete mutation sweep."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import time

ROOT = Path('/Volumes/Stripe/geode-fem/codex-issue-1202')
ARCHIVE = Path(__file__).resolve().parent
OUT = ARCHIVE / 'native-final-candidate'
HARNESS = 'benchmarks/motor_optimization/harness'
PYRUN = f'{HARNESS}/pyrun.sh'
BUILD = ROOT / 'target/build-reviewed-final-candidate-20261018'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, text=True).strip()


def main():
    sweep = ARCHIVE / 'harness-mutations-reviewed-receipt.json'
    if not sweep.is_file():
        raise RuntimeError('mutation sweep is not terminal; do not overlap it')
    receipt = json.loads(sweep.read_text())
    if receipt.get('exit_code') != 0:
        raise RuntimeError('mutation sweep did not exit successfully')
    lines = (ARCHIVE / 'harness-mutations-reviewed.log').read_text().splitlines()
    killed = [x for x in lines if ': KILLED' in x]
    if len(killed) != 98 or any(': SURVIVED' in x for x in lines):
        raise RuntimeError('full 98-mutation evidence is missing')
    if git('status', '--porcelain'):
        raise RuntimeError('source tree was not restored cleanly')
    commit = git('rev-parse', 'HEAD')
    if not commit.startswith('bc1527e8'):
        raise RuntimeError('candidate changed; review runner before use')
    OUT.mkdir(exist_ok=False)
    env = dict(os.environ, CARGO_TARGET_DIR=str(ROOT / 'target'))
    state = {'source_commit': commit, 'runner_sha256': sha(__file__),
             'mutation_receipt_sha256': sha(sweep), 'status': 'running', 'steps': []}

    def save():
        (OUT / 'verification.json').write_text(json.dumps(state, indent=2) + '\n')

    def run(name, command, allowed=(0,)):
        if git('rev-parse', 'HEAD') != commit or git('status', '--porcelain'):
            raise RuntimeError('source changed before ' + name)
        log = OUT / (name + '.log')
        item = {'name': name, 'command': list(map(str, command)), 'status': 'running',
                'started_unix': time.time(), 'allowed_exit_codes': list(allowed)}
        state['steps'].append(item)
        save()
        print('START', name, flush=True)
        started = time.monotonic()
        with log.open('x') as stream:
            result = subprocess.run(item['command'], cwd=ROOT, env=env,
                                    stdout=stream, stderr=subprocess.STDOUT)
        item.update(exit_code=result.returncode, wall_seconds=time.monotonic()-started,
                    log_sha256=sha(log), status='terminal')
        save()
        print('END', name, 'exit', result.returncode, flush=True)
        if result.returncode not in allowed:
            raise RuntimeError(name + ' exited unexpectedly')
        if git('rev-parse', 'HEAD') != commit or git('status', '--porcelain'):
            raise RuntimeError('source changed during ' + name)

    try:
        run('python-tests', [PYRUN, '-m', 'unittest', 'discover', '-s', HARNESS,
                             '-p', 'test_*.py', '-v'])
        run('recorded-build', [PYRUN, f'{HARNESS}/build_provenance.py', '--out', BUILD])
        binary = BUILD / 'icem_harness_eval'
        verify = ('import sys,json; from pathlib import Path; '
                  f'sys.path.insert(0,{str(ROOT / HARNESS)!r}); '
                  'import build_provenance,recovery_bindings; '
                  f'print(json.dumps(build_provenance.verify(Path({str(BUILD / "build-receipt.json")!r}), '
                  f'Path({str(binary)!r}), recovery_bindings.sources(Path({str(ROOT)!r}))),sort_keys=True))')
        run('verify-build', [PYRUN, '-c', verify])
        run('gmsh-repair-attempts', ['cargo', 'test', '--locked', '--release', '-p',
             'geode-core', '--test', 'motor_experiment2_domain',
             'every_repair_attempt_meshes_theta0_through_gmsh', '--', '--ignored', '--nocapture'])
        for script, name in [('make_starts', 'starts-recheck'), ('start_preflight', 'start-preflight')]:
            run(name, [PYRUN, f'{HARNESS}/{script}.py', '--binary', binary,
                       '--out', OUT / (name + '.json')])
        old = json.loads((ROOT / HARNESS / 'starts.json').read_text())
        new = json.loads((OUT / 'starts-recheck.json').read_text())
        for value in (old, new):
            del value['preflight']['wall_seconds']
        if old != new:
            raise RuntimeError('regenerated starts differ beyond preflight wall time')
        state['starts_exact_except_wall_seconds'] = True
        save()
        for space in 'ab':
            for newton in ('default', 'tight'):
                name = f'gradient-{space}-{newton}'
                run(name, [PYRUN, f'{HARNESS}/l0_gradient_check.py', '--binary', binary,
                           '--space', space, '--newton', newton, '--out', OUT / (name+'.json')],
                    allowed=(0,) if space == 'a' else (1,))
        for newton in ('default', 'tight'):
            name = f'gradient-b-{newton}-boundary'
            run(name, [PYRUN, f'{HARNESS}/l0_gradient_check.py', '--binary', binary,
                       '--space', 'b', '--newton', newton, '--boundary-start',
                       '--out', OUT / (name+'.json')])
        for space in 'ab':
            name = f'mixed-model-{space}'
            run(name, [PYRUN, f'{HARNESS}/mixed_model_smoke.py', '--binary', binary,
                       '--space', space, '--out', OUT / (name+'.json')])
        run('resource-wiring', [PYRUN, f'{HARNESS}/resource_wiring_smoke.py', '--binary', binary,
                               '--out', OUT / 'resource-wiring.json'])
        state['status'] = 'commands_completed_requires_artifact_review'
        state['review_required'] = ('Inspect every artifact, especially B central theta0 bound '
             'rejection, passing B interior, and all source/resource bindings; exit codes alone are insufficient.')
    except BaseException as error:
        state.update(status='failed_or_interrupted', error=f'{type(error).__name__}: {error}')
        raise
    finally:
        save()


if __name__ == '__main__':
    main()
