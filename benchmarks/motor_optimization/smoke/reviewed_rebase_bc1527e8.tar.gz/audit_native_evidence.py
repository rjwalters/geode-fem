"""Review retained native records without importing the experiment harness."""
from pathlib import Path
import hashlib
import json
import math
import subprocess

BASE = Path(__file__).resolve().parent
OUT = BASE / 'native-final-candidate'
ROOT = Path('/Volumes/Stripe/geode-fem/codex-issue-1202')
COMMIT = 'bc1527e83b4e0e04f792892f45f77d58dabb3c3a'
BINARY = 'c62c2e4e5249c399b4c073142123b7a23c70bb5e827ca423fd69ee55a4dfd272'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(name):
    return json.loads((OUT / name).read_text())


def bind(record):
    assert record['base_commit'] == COMMIT
    assert record['binary_sha256'] == BINARY
    if 'tree_clean' in record:
        assert record['tree_clean'] is True
    for field in ('source_sha256', 'input_sha256'):
        for name, digest in record.get(field, {}).items():
            path = (ROOT / 'benchmarks/motor_optimization/harness' / name
                    if field == 'source_sha256' and '/' not in name else ROOT / name)
            assert sha(path) == digest, name


def resources(record):
    receipt = record['child_receipt']
    assert receipt['state'] == 'reaped' and receipt['returncode'] == 0
    assert receipt['cpu_complete'] is True
    assert all(r['measurement']['cpu_complete'] for r in record['requests'])


def main():
    runner = load('verification.json')
    assert runner['status'] == 'commands_completed_requires_artifact_review'
    assert runner['source_commit'] == COMMIT
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == COMMIT
    assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT)
    for step in runner['steps']:
        assert step['status'] == 'terminal'
        assert step['exit_code'] in step['allowed_exit_codes']
        assert sha(OUT / (step['name'] + '.log')) == step['log_sha256']
    starts = load('starts-recheck.json')
    frozen = json.loads((ROOT / 'benchmarks/motor_optimization/harness/starts.json').read_text())
    for record in (starts, frozen):
        del record['preflight']['wall_seconds']
    assert starts == frozen
    preflight = load('start-preflight.json')
    bind(preflight)
    assert preflight['status'] == 'PASS' and preflight['fem_solves'] == 0
    assert {(s['space'], s['level']) for s in preflight['sessions']} == {(s, l) for s in 'ab' for l in (0, 1)}
    for session in preflight['sessions']:
        assert session['status'] == 'PASS' and len(session['checks']) == 5
        assert all(c['status'] == 'PASS' for c in session['checks'])
        resources(session['resources'])
    gradients = []
    expected_rejections = []
    files = sorted(OUT.glob('gradient-*.json'))
    assert len(files) == 6
    for path in files:
        record = json.loads(path.read_text())
        bind(record)
        boundary = path.stem.endswith('-boundary')
        expected_rejection = record['space'] == 'b' and not boundary
        assert record['status'] == ('failed' if expected_rejection else 'PASS')
        assert record['criterion']['h'] == 1e-4
        assert record['criterion']['relative_error_below'] == 1e-5
        assert record['criterion']['no_best_step_selection'] is True
        assert [p['point'] for p in record['points']] == (['theta0'] if boundary else ['theta0', 'interior'])
        for point in record['points']:
            resources(point['resources'])
            if expected_rejection and point['point'] == 'theta0':
                assert point['status'] == 'failed' and point['directional'] == []
                assert point['error'] == 'ValueError: check: failed or wrong design reply'
                assert all(r['request']['op'] == 'check' for r in point['requests'])
                reply = point['requests'][-1]['reply']
                assert reply['ok'] is False
                assert reply['error'] == 'CPR1 = 0.0000001869176962500001 outside [-0.0015, 0]'
                assert all(c['forward_solves'] == c['adjoint_solves'] == 0 for r in point['requests'] for c in r['reply']['charges'])
                expected_rejections.append({'file': path.name, 'error': reply['error'], 'fem_solves': 0})
                continue
            assert point['status'] == 'PASS' and point['criterion_passed'] is True
            trains = [r['reply'] for r in point['requests'] if r['request']['op'] == 'train']
            assert len(trains) == 7
            assert all(r['ok'] and r['status'] == 'ok' and r['generation'] == 0 and r['event'] is None for r in trains)
            assert all(r['reply']['ok'] for r in point['requests'])
            base = trains[0]
            assert [r['h'] for r in point['directional']] == [1e-3, 1e-4, 1e-5]
            for index, row in enumerate(point['directional']):
                plus, minus = trains[1+2*index:3+2*index]
                for observable, gradient, suffix in [('F', 'dF', 'dF'), ('mean_full', 'dmean_full', 'dmean_full')]:
                    adjoint = sum(g*d for g, d in zip(base[gradient], point['direction']))
                    numerator = (-3*base[observable]+4*plus[observable]-minus[observable]) if boundary else (plus[observable]-minus[observable])
                    fd = numerator/(2*row['h'])
                    assert math.isclose(adjoint, row['adjoint_'+suffix], rel_tol=1e-13, abs_tol=1e-15)
                    assert math.isclose(fd, row['fd_'+suffix], rel_tol=1e-13, abs_tol=1e-15)
                    assert adjoint != 0
                    assert math.isclose(abs(fd-adjoint)/abs(adjoint), row['rel_'+suffix], rel_tol=1e-10, abs_tol=1e-15)
                if row['h'] == 1e-4:
                    assert row['rel_dF'] < 1e-5 and row['rel_dmean_full'] < 1e-5
                    gradients.append({'file': path.name, 'point': point['point'], 'boundary': boundary,
                                      'h': row['h'], 'rel_dF': row['rel_dF'], 'rel_dmean_full': row['rel_dmean_full']})
    assert len(gradients) == 8 and len(expected_rejections) == 2
    mixed = []
    for space in 'ab':
        record = load(f'mixed-model-{space}.json')
        bind(record)
        assert record['status'] == 'PASS'
        assert record['ready']['session']['training']['level'] == 0
        assert record['ready']['session']['validation']['level'] == 2
        assert record['train']['ok'] and record['validate']['ok']
        assert record['train']['dF'] is not None
        resources(record['run_evaluator_resources'])
        diagnostic = record['diagnostic']
        assert diagnostic['status'] == 'ok' and diagnostic['counted_in_run_budget'] is False
        assert diagnostic['resources']['cpu_complete'] is True
        resources(diagnostic['resources']['evaluator'])
        mixed.append({'space': space, 'status': record['status'], 'diagnostic': diagnostic['status']})
    resource = load('resource-wiring.json')
    bind(resource)
    assert resource['train_ok'] is True
    assert resource['expected_validation_failure'] == 'validate needs an anchor (--anchor)'
    resources(resource['resources'])
    assert resource['startup_failure']['child_receipt']['state'] == 'reaped'
    assert resource['startup_failure']['child_receipt']['returncode'] == 2
    result = {'status': 'PASS', 'source_commit': COMMIT, 'binary_sha256': BINARY,
              'scope': 'Retained native numerical/setup evidence and source/resource bindings; no optimizer or speedup claim',
              'starts_exact_except_wall_seconds': True, 'preflight_checks': 20, 'preflight_fem_solves': 0,
              'gradient_checks': gradients, 'expected_bound_rejections': expected_rejections,
              'mixed_model_checks': mixed, 'resource_wiring': 'PASS',
              'audit_script_sha256': sha(Path(__file__)),
              'artifact_sha256': {p.name: sha(p) for p in sorted(OUT.glob('*.json'))}}
    target = BASE / 'native-evidence-audit.json'
    with target.open('x') as stream:
        json.dump(result, stream, indent=2); stream.write('\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
