import json, subprocess, time
from pathlib import Path
root=Path("/Volumes/Stripe/geode-fem/codex-issue-1202")
out=Path(__file__).resolve().parent
h="benchmarks/motor_optimization/harness/"
rows=[]
files=["test_safeguards.py","test_recovery_execution.py","test_diagnostic_repair.py","test_evaluator_resources.py","test_anchor_preflight.py","test_recovery_policy.py","baseline_wiring_mutations.py","anchor_preflight_mutations.py","recovery_policy_mutations.py"]
for name in files:
    start=time.monotonic()
    result=subprocess.run([h+"pyrun.sh",h+name],cwd=root,capture_output=True,text=True,timeout=90)
    (out/(name+".final.stdout")).write_text(result.stdout)
    (out/(name+".final.stderr")).write_text(result.stderr)
    row={"name":name,"exit_code":result.returncode,"seconds":time.monotonic()-start}
    rows.append(row)
    (out/"verification-final.json").write_text(json.dumps({"steps":rows,"complete":len(rows)==len(files)},indent=2)+"\n")
    print(json.dumps(row),flush=True)
    if result.returncode: raise SystemExit(result.returncode)
