import hashlib, io, json, re, subprocess, tarfile
from pathlib import Path
root=Path('/Volumes/Stripe/geode-fem/codex-issue-1202')
h=root/'benchmarks/motor_optimization/harness'
out=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
assert commit.startswith('6f01b4a5')
checks=[]
for name,suffix in [('test_harness.py',''),('test_run_interruption.py',''),('test_physical_diagnostic.py',''),('test_safeguards.py','.final'),('test_recovery_execution.py','.final'),('test_diagnostic_repair.py','.final'),('test_evaluator_resources.py','.final'),('test_anchor_preflight.py','.final'),('test_recovery_policy.py','.final')]:
    log=out/(name+suffix+'.stderr')
    text=log.read_text()
    assert text.rstrip().endswith('OK'), name
    checks.append({'name':name,'tests':int(re.search(r'Ran (\d+) tests?',text).group(1)),'status':'PASS','log':log.name})
mutations=[]
source_sha256={p.name:sha(p) for p in h.glob('*.py')}
for name in ('baseline_wiring','anchor_preflight','recovery_policy'):
    path=out/(name+'_mutations.py.final.stdout')
    d=json.loads(path.read_text())
    assert all(c['expected_result'] for c in d['checks'])
    assert d['baseline_source_sha256']==source_sha256, name
    mutants=[c for c in d['checks'] if not c['name'].startswith('baseline')]
    assert all(c['exit_code']!=0 and 'AssertionError' in c['stderr'] for c in mutants)
    mutations.append({'suite':name,'status':'PASS','baseline_checks':len(d['checks'])-len(mutants),'faults_detected':len(mutants),'log':path.name,'mutants':[c['name'] for c in mutants]})
    if name=='baseline_wiring':
        baseline=d['checks'][0]
        checks.append({'name':'test_baseline_wiring.py','tests':int(re.search(r'Ran (\d+) tests?',baseline['stderr']).group(1)),'status':'PASS','log':path.name+'#baseline'})
native=json.loads((out/'native-mixed-a.json').read_text())
assert native['status']=='PASS' and native['base_commit']==commit and native['tree_clean']
assert native['diagnostic']['evaluator_ready']['train_msh_sha256']==native['ready']['train_msh_sha256']
build=root/'target/build-pr-head-848fa480'
receipt=json.loads((build/'build-receipt.json').read_text())
assert sha(build/'icem_harness_eval')==receipt['binary']['sha256']==native['binary_sha256']
# Compare all recorded native build files, while retaining Python changes explicitly.
native_files={k:v for k,v in receipt['source']['files'].items() if k.startswith('crates/') or k in ('Cargo.lock','Cargo.toml','rust-toolchain.toml')}
assert all(sha(root/p)==v for p,v in native_files.items())
summary={'schema':1,'status':'PASS','issue':1202,'review_pr':1206,'source_commit':commit,
 'scope':'Doctor delta only: observed training-mesh binding, mean-relative normalization coverage, completed-contaminated recovery coverage. No main optimization result.',
 'python_checks':checks,'python_tests':sum(c['tests'] for c in checks),'mutations':mutations,'faults_detected':sum(m['faults_detected'] for m in mutations),
 'source_sha256':source_sha256,
 'native_smoke':{'space':'a','status':native['status'],'source_commit':native['base_commit'],'tree_clean':native['tree_clean'],'wall_seconds':native['wall_seconds'],'binary_sha256':native['binary_sha256'],'build_source_commit':receipt['source']['commit'],'build_receipt_sha256':sha(build/'build-receipt.json'),'native_build_files_verified_unchanged':len(native_files),'scope':'Reused witnessed 848fa480 binary; current Python driver/diagnostic path at 6f01b4a5. Not a final-source build receipt for launching the main study.'},
 'limitations':['Targeted local verification; the complete Python/native suite is delegated to remote CI on the pushed head.','The native smoke exercises matching L0/L2 inputs in space a; refusal paths and all five methods use controlled evaluator tests.','Initial fixture failures and successful reruns are retained; test_physical_diagnostic.py initial failure log was overwritten by its successful rerun.','Older evidence records have distinct source/binary provenance and are retained as historical records.']}
(out/'doctor-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
files={p.name:p for p in out.iterdir() if p.is_file() and p.name not in ('package-evidence.py','pr-body.md','review-comment.md')}
files['package-evidence.py']=Path(__file__).resolve()
for name in ('build-receipt.json','inputs.json','cargo.log'):
    files['reused-build/'+name]=build/name
inventory={k:sha(v) for k,v in sorted(files.items())}
archive=root/'benchmarks/motor_optimization/smoke/doctor_training_mesh_6f01b4a5.tar.gz'
assert not archive.exists()
with tarfile.open(archive,'w:gz') as tar:
    for name,p in sorted(files.items()): tar.add(p,arcname=name,recursive=False)
    payload=(json.dumps(inventory,indent=2)+'\n').encode()
    item=tarfile.TarInfo('SHA256.json');item.size=len(payload);tar.addfile(item,io.BytesIO(payload))
with tarfile.open(archive,'r:gz') as tar:
    recovered=json.load(tar.extractfile('SHA256.json'))
    assert recovered==inventory
    for name,value in recovered.items(): assert hashlib.sha256(tar.extractfile(name).read()).hexdigest()==value,name
summary['archive']={'path':str(archive.relative_to(root)),'sha256':sha(archive),'files':len(files),'each_member_verified':True}
(h/'doctor-training-mesh-checks.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({k:summary[k] for k in ('python_tests','faults_detected','archive')}))
