import hashlib,io,json,re,subprocess,tarfile
from pathlib import Path
root=Path('/Volumes/Stripe/geode-fem/codex-issue-1203-selector')
h=root/'benchmarks/motor_optimization/final_refinement'
p=Path(__file__).resolve().parent
sha=lambda x:hashlib.sha256(x.read_bytes()).hexdigest()
commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
assert commit=='8fc3efe07ef734cb20c8feb529441e2f5a592ac0'
mut=json.loads((p/'archive-mutations.json').read_text())
assert all(c['expected_result'] for c in mut['checks'])
assert all(sha(h/name)==value for name,value in mut['source_sha256'].items())
probe=json.loads((p/'harness-probe-v2.json').read_text())
assert probe['status']=='PASS' and probe['source_files_unchanged']
assert all(sha(h/name)==value for name,value in probe['adapter_source_sha256'].items())
files={str(f.relative_to(p)):f for f in p.rglob('*') if f.is_file() and '__pycache__' not in f.parts}
inventory={name:sha(file) for name,file in files.items()}
archive=h/'trace_archive_8fc3efe0.tar.gz'
assert not archive.exists()
with tarfile.open(archive,'w:gz') as tar:
 for name,file in sorted(files.items()):tar.add(file,arcname=name,recursive=False)
 data=(json.dumps(inventory,indent=2)+'\n').encode();info=tarfile.TarInfo('SHA256.json');info.size=len(data);tar.addfile(info,io.BytesIO(data))
with tarfile.open(archive,'r:gz') as tar:
 assert json.load(tar.extractfile('SHA256.json'))==inventory
 for name,value in inventory.items():assert hashlib.sha256(tar.extractfile(name).read()).hexdigest()==value
summary={'schema':1,'status':'PASS','source_commit':commit,'scope':'Generation byte/identity loader only; synthetic archives and actual writer with synthetic evaluator. No FEM, scientific eligibility or main study.',
 'unit_tests':int(re.search(r'Ran (\d+) tests',mut['checks'][0]['stderr']).group(1)),
 'mutations_detected':len(mut['checks'])-1,'mutations':[c['name'] for c in mut['checks'][1:]],
 'source_sha256':mut['source_sha256'],
 'writer_schema_probe':{'status':'PASS','harness_commit':probe['harness_commit'],'jobs':probe['loaded_jobs'],'attempts':probe['loaded_attempts'],'source_files_unchanged':True,'log':'harness-probe-v2.json'},
 'archive':{'file':archive.name,'sha256':sha(archive),'files':len(files),'each_member_verified':True},
 'limitations':['Recovery-chain and external-attestation reconciliation remains pending.', 'Canonical source/runtime/anchor, scientific geometry/mesh, mean floor, target and timing checks remain pending.', 'Local lock inactivity on a copied archive does not establish remote process absence.', 'Full integration and native execution await reviewed dependencies.']}
(h/'trace-archive-checks.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({k:summary[k] for k in ('unit_tests','mutations_detected','archive')}))
