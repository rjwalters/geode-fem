import hashlib,json,subprocess,sys
from pathlib import Path
from unittest import mock
h=Path('/Volumes/Stripe/geode-fem/codex-issue-1202/benchmarks/motor_optimization/harness')
p=Path('/Volumes/Stripe/geode-fem/codex-issue-1203-selector/benchmarks/motor_optimization/final_refinement')
sys.path[:0]=[str(p),str(h)]
from test_trace_archive import Fixture,write,digest
from test_run_interruption import fixture,successful_prefix
from test_harness import FakeEvaluator,FakeClock
import driver,main_schedule,run
from trace_archive import load_generation
out=Path(__file__).resolve().parent
root=out/'generation'; f=Fixture(root)
config=fixture(root);config.update(label='main',budget_fe=120.)
f.session=config
write(root/'session.json',config);f.rebind('session.json')
for name in ('calibration_primary.json','calibration_secondary.json'):
 write(root/name,{'accepted_for_dispatch':True,'calibration':{'unit_seconds':config['unit_seconds']}});f.rebind(name)
assert f.queue==main_schedule.registered_jobs(driver.METHOD_SPECS)
for job in f.queue[:5]:
 aid=f.emit('attempt_created',job=job,suffix='')
 name=f"native-schema-{job['method_letter']}.json"
 f.emit('attempt_dispatched',attempt_id=aid,trace=name)
 clock=FakeClock()
 with mock.patch.object(run,'execute',successful_prefix):
  raw=run.run_one(config,job['method'],'a','theta0',1,root/name,position=job['position'],clock=clock,
   evaluator_factory=lambda space,ledger:FakeEvaluator(clock),diagnostic=False)
 assert raw['stop_reason']=='converged',raw.get('error')
 assert len(raw['validations'])==1
 f.emit('attempt_finished',attempt_id=aid,result={'status':'ran','exit':0,'trace':name,
  'trace_sha256':digest(root/name),'host_contaminated':False})
before={str(x.relative_to(root)):digest(x) for x in root.rglob('*') if x.is_file()}
loaded=load_generation(root)
assert len(loaded['jobs'])==100 and len(loaded['attempts'])==5
assert all(a['terminal_bound'] and len(a['trace']['validations'])==1 for a in loaded['attempts'])
assert before=={str(x.relative_to(root)):digest(x) for x in root.rglob('*') if x.is_file()}
summary={'status':'PASS','scope':'Actual run.py and queue writer schema, with synthetic evaluator and patched bounded optimizer prefix; no FEM, real main run, timing claim or cohort eligibility.',
 'harness_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=h,text=True).strip(),
 'harness_source_sha256':{x.name:digest(x) for x in h.glob('*.py')},
 'adapter_source_sha256':{x.name:digest(x) for x in (p/'trace_archive.py',p/'test_trace_archive.py')},
 'loaded_jobs':len(loaded['jobs']),'loaded_attempts':len(loaded['attempts']),
 'source_files_unchanged':True,'retained_files':before}
write(out/'harness-probe.json',summary)
print(json.dumps({k:summary[k] for k in ('status','scope','loaded_jobs','loaded_attempts')}))
