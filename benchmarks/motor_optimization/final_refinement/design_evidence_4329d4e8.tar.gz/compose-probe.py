import copy,hashlib,json,sys
from dataclasses import asdict
from pathlib import Path
root=Path(__file__).resolve().parent
code=Path('/Volumes/Stripe/geode-fem/codex-issue-1203-selector/benchmarks/motor_optimization/final_refinement')
sys.path.insert(0,str(code))
from design_evidence import RegisteredDesigns
from validation_evidence import adapt_validation
from selection import select
from check_plan import make_plan
repo=Path('/Volumes/Stripe/geode-fem/codex-issue-1202')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
reference=repo/'benchmarks/motor_reference/reference_data.json';starts=repo/'benchmarks/motor_optimization/harness/starts.json'
definitions=RegisteredDesigns.load(reference,starts,reference_sha256=sha(reference),starts_sha256=sha(starts))
retained=Path('/Volumes/Stripe/scratch-codex-review/issue1206-doctor-training-mesh/native-mixed-a.json')
prior=Path('/Volumes/Stripe/scratch-codex-review/issue1203-validation-evidence/final-probe/native-schema-probe.json')
# Retain the two inputs for this combined replay, including their original bytes.
for source,name in ((retained,'retained-native-mixed-a.json'),(prior,'retained-validation-schema.json')):
 (root/name).write_bytes(source.read_bytes())
actual=json.loads(retained.read_text());previous=json.loads(prior.read_text())
assert sha(retained)==previous['retained_native_smoke_sha256']
sessions=[json.loads((root/(s+'.json')).read_text()) for s in 'ab']
provenance={k:sessions[0]['checks'][0]['adapted']['settings'][k] for k in ('source_commit','binary_sha256','source_files_sha256')}
record=copy.deepcopy(previous['validation_record'])
record['x']=actual['validate']['x'];record['x_bits']=actual['validate']['x_bits']
trace={'space':'a','evaluator_ready':sessions[0]['ready'],'anchor':sessions[0]['ready']['anchor']}
design=definitions.adapt(trace,record,provenance=provenance)
assert design['x_bits']==sessions[0]['checks'][0]['reply']['x_bits']
geometry=sessions[0]['checks'][0]['reply']['geometry']
checks=dict(anchor=trace['anchor'],unit_seconds=2.,budget_fe=120.,guard_specs=previous['guard_specs'],
 discrete_names=[d['name'] for d in geometry['discrete']])
context=dict(run_id='schema-only#0',source_sha256=sha(retained),method='D',space='a',start_index=0,repeat=1,
 eligible_run=True,host_contaminated=False,stop_reason='error')
validation=adapt_validation(record,context=context,design=design['design'],**checks)
btrace={'space':'b','evaluator_ready':sessions[1]['ready'],'anchor':sessions[1]['ready']['anchor']}
b=definitions.adapt(btrace,{'x':sessions[1]['ready']['space']['x0']},provenance=provenance)
selection=select([validation],f0=checks['anchor']['F0'],mean0=checks['anchor']['mean0_full_current'],
 theta0=design['theta0'],theta0_references=[b['theta0']])
assert selection['records'][0]['rejection_reasons']==['mean_floor_not_met']
assert all(c['status']=='unavailable' for c in selection['cells'])
plan=make_plan(selection)
assert len(plan['reference_design_keys'])==2 and len(plan['jobs'])==12
out={'status':'PASS','scope':'Compose retained native theta0 values and coordinates with real ready replies, full design mapping, validation checks, selector and reference plan. Time/run/host context remains synthetic, so no main-study eligibility or refinement result.',
 'input_sha256':{n:sha(root/n) for n in ('a.json','b.json','retained-native-mixed-a.json','retained-validation-schema.json')},
 'validation_record':record,'context':context,'adapted_validation':asdict(validation),'selection':selection,'plan':plan}
(root/'composed-probe.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'status':'PASS','rejection_reasons':selection['records'][0]['rejection_reasons'],'reference_checks':len(plan['jobs'])}))
