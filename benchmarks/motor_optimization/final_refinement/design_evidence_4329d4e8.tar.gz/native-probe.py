import hashlib,json,sys
from dataclasses import asdict
from pathlib import Path
repo=Path('/Volumes/Stripe/geode-fem/codex-issue-1202')
code=Path('/Volumes/Stripe/geode-fem/codex-issue-1203-selector/benchmarks/motor_optimization/final_refinement')
harness=repo/'benchmarks/motor_optimization/harness'
sys.path.insert(0,str(harness));sys.path.insert(0,str(code))
from design_evidence import RegisteredDesigns
from evaluator import Evaluator,to_bits
from run import thread_env
out=Path(__file__).resolve().parent
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
base=repo/'target/build-pr-head-848fa480'
binary=base/'icem_harness_eval';receipt_path=base/'build-receipt.json'
receipt=json.loads(receipt_path.read_text())
assert sha(binary)==receipt['binary']['sha256']
source=receipt['source']
# Check the native sources and reference used by this earlier witnessed binary.
native={n:v for n,v in source['files'].items() if n.startswith('crates/') or n in ('Cargo.toml','Cargo.lock','rust-toolchain.toml','benchmarks/motor_reference/reference_data.json')}
assert all(sha(repo/n)==v for n,v in native.items())
reference=repo/'benchmarks/motor_reference/reference_data.json';starts=harness/'starts.json'
definitions=RegisteredDesigns.load(reference,starts,reference_sha256=sha(reference),starts_sha256=sha(starts))
provenance={'source_commit':source['commit'],'binary_sha256':sha(binary),
 'source_files_sha256':hashlib.sha256(json.dumps(source['files'],sort_keys=True,separators=(',',':')).encode()).hexdigest()}
train=repo/'benchmarks/motor_reference/geometry/meshes/icem_initial_sector_L0.msh'
val=repo/'benchmarks/motor_reference/geometry/meshes/icem_initial_sector_L2.msh'
anchor=repo/'benchmarks/motor_optimization/anchor.json'
inputs={str(p):sha(p) for p in (binary,receipt_path,reference,starts,train,val,anchor)}
code_hashes={n:sha(code/n) for n in ('design_evidence.py','selection.py','trace_archive.py')}
raw_starts=json.loads(starts.read_text());sessions=[]
for space in 'ab':
 command=[str(binary),'--space',space,'--train-mesh',str(train),'--train-level','0',
  '--val-mesh',str(val),'--val-level','2','--anchor',str(anchor)]
 ev=Evaluator(command,env=thread_env(),timeout=120,stderr_path=out/(space+'.stderr.log'))
 row={'space':space,'command':command,'ready':ev.ready,'checks':[]};sessions.append(row)
 try:
  assert ev.ready['train_msh_sha256']==sha(train)
  assert ev.ready['validation_msh_sha256']==sha(val)
  trace={'space':space,'anchor':ev.ready['anchor'],'evaluator_ready':ev.ready}
  for name in ('theta0','lhs1','lhs2','lhs3','lhs4'):
   x=raw_starts['starts'][name][space]
   reply=ev.request('geometry',timeout=120,x_bits=to_bits(x))
   assert reply['ok'] and reply['x_bits']==to_bits(x)
   assert reply['charges'] and all(c['forward_solves']==0 and c['adjoint_solves']==0 for c in reply['charges'])
   adapted=definitions.adapt(trace,{'x':x,'x_bits':reply['x_bits']},provenance=provenance)
   assert len(adapted['parameters'])==22
   assert adapted['x_bits']==reply['x_bits']
   row['checks'].append({'start':name,'reply':reply,'adapted':{k:asdict(v) if k in ('design','theta0') else v for k,v in adapted.items()}})
 finally:
  ev.close();row['resources']=ev.resources()
 assert row['resources']['child_receipt']['state']=='reaped'
 (out/(space+'.json')).write_text(json.dumps(row,indent=2)+'\n')
a=sessions[0]['checks'][0]['adapted'];b=sessions[1]['checks'][0]['adapted']
assert a['parameters']==b['parameters'] and a['design']['canonical']!=b['design']['canonical']
assert all(sha(Path(p))==v for p,v in inputs.items())
assert all(sha(code/n)==v for n,v in code_hashes.items())
summary={'status':'PASS','scope':'Real evaluator readiness and geometry-only requests at the five frozen starts in both spaces; zero FEM or optimizer solves. Source/capture authentication for a main study remains separate.',
 'new_FEM_solves':0,'native_sessions':2,'coordinates_checked':10,'parameters_per_design':22,
 'source_commit':source['commit'],'binary_sha256':sha(binary),'source_sha256':code_hashes,
 'input_sha256':inputs,'native_source_files_checked':len(native),'same_theta0_parameters_distinct_map_identity':True,
 'retained_build_receipt_sha256':sha(receipt_path),'python':sys.version}
(out/'native-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
