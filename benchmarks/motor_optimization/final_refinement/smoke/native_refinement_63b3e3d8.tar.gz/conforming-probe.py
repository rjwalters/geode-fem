import hashlib,json,os,pathlib,subprocess,time
out=pathlib.Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
receipt=json.loads((out/'build-receipt.json').read_text());binary=out/'icem_final_refinement'
assert receipt['status']=='PASS' and sha(binary)==receipt['binary_sha256']
req=json.loads((out/'a-primary.request.json').read_text());req['check']='conforming'
path=out/'a-conforming.request.json';path.write_text(json.dumps(req,indent=2)+'\n')
mesh=pathlib.Path('/Volumes/Stripe/geode-fem/codex-issue-1202/benchmarks/motor_reference/geometry/meshes/icem_initial_sector_L2.msh')
command=[str(binary),'--request',str(path),'--mesh',str(mesh),'--out',str(out/'a-conforming')]
t=time.monotonic()
with (out/'a-conforming.stdout').open('x') as stdout,(out/'a-conforming.stderr').open('x') as stderr:
 done=subprocess.run(command,env=dict(os.environ,RAYON_NUM_THREADS='1',GEODE_NUM_THREADS='1'),stdout=stdout,stderr=stderr,timeout=600)
result=json.loads((out/'a-conforming/result.json').read_text())
summary={'scope':'Real fresh conforming theta0 wiring; no optimizer or speedup result.','command':command,'returncode':done.returncode,'wall_seconds':time.monotonic()-t,'result_sha256':sha(out/'a-conforming/result.json'),'status':'observed'}
(out/'conforming-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
assert done.returncode==0 and result['ok'] is True,result
assert result['resources']['cpu_complete'] is True
assert result['config']['mode']=='conforming-outer',result['config']
assert result['forced_fresh_attempts'][-1]['outcome']=='passed'
assert len(result['fresh_mesh_records'])>=1
for record in result['fresh_mesh_records']:
 if record['file']:
  actual=pathlib.Path(record['file']);assert actual.is_relative_to(out/'a-conforming/meshes')
  assert sha(actual)==record['sha256']
assert result['validation']['msh_sha256']==result['fresh_mesh_records'][-1]['sha256']
assert len(result['validation']['currents'])==3 and all(len(c['torques'])==20 for c in result['validation']['currents'])
summary.update(status='PASS',mesh_attempts=len(result['forced_fresh_attempts']),waveform_samples=60)
(out/'conforming-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary))
