import hashlib,json,pathlib,tarfile
root=pathlib.Path('/Volumes/Stripe/geode-fem/codex-issue-1203-selector')
out=pathlib.Path(__file__).resolve().parent;here=root/'benchmarks/motor_optimization/final_refinement'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
probe=json.loads((out/'probe-summary.json').read_text());fresh=json.loads((out/'conforming-summary.json').read_text());build=json.loads((out/'build-receipt.json').read_text())
assert probe['status']==fresh['status']==build['status']=='PASS'
for name,digest in build['source_sha256'].items():assert sha(root/name)==digest,name
payload=[p for p in sorted(out.rglob('*')) if p.is_file() and p.name not in ('icem_final_refinement','manifest.json')]
manifest={str(p.relative_to(out)):sha(p) for p in payload}
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
archive=here/'smoke/native_refinement_63b3e3d8.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
 for p in payload+[out/'manifest.json']:tar.add(p,arcname=str(p.relative_to(out)),recursive=False)
with tarfile.open(archive,'r:gz') as tar:
 for name,digest in manifest.items():assert hashlib.sha256(tar.extractfile(name).read()).hexdigest()==digest
summary={'schema':1,'status':'PASS','source_commit':build['source_commit'],'scope':'Native exact-coordinate post-run executor wiring only; no main cohort, optimizer or speedup result.','source_sha256':{name:sha(root/name) for name in ('crates/geode-core/examples/icem_final_refinement.rs','crates/geode-core/tests/common/icem_final_refinement.rs','crates/geode-core/tests/common/icem_experiment2.rs','crates/geode-core/tests/common/motor_resources.rs','crates/geode-core/tests/motor_final_refinement.rs')},'unit_tests':{'passed':6,'command':'CARGO_TARGET_DIR=/Volumes/Stripe/geode-fem/codex-issue-1203-selector/target cargo test -p geode-core --test motor_final_refinement --no-default-features','scope':'Registered matrix, exact coordinates/maps/frozen expansion, input hashes, unknown overrides, conforming zero-stator/rotation gate, remesh history on forward failure and reset.'},'format_check':'cargo fmt --all -- --check: PASS','ci_target_coverage':'python3 scripts/ci-test-coverage.py: PASS (225/226 targets, one previously allowlisted)','build':{k:build[k] for k in ('command','source_commit','binary_sha256','environment_overrides','elapsed_seconds','source_unchanged')},'native_checks':probe,'fresh_conforming':fresh,'raw_waveform_samples':240,'archive':{'file':str(archive.relative_to(here)),'sha256':sha(archive),'files':len(payload)+1,'each_payload_member_verified':True},'remaining':['Native L3/g40/tight/withheld and moved candidate execution are not covered by this bounded smoke.','Complete closed-study capture/source/runtime authentication and frozen-cohort driver remain pending.','Independent review is required before scientific interpretation.','Full main study, final refinement results, manuscript and audit remain pending.']}
(here/'native-execution-checks.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({'archive':summary['archive'],'samples':240,'status':'PASS'}))
