import hashlib,json,os,pathlib,platform,shutil,subprocess,time
root=pathlib.Path.cwd();out=pathlib.Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
files=[root/n for n in subprocess.check_output(['git','ls-files'],text=True).splitlines() if n.endswith('.rs') or pathlib.Path(n).name in ('Cargo.toml','Cargo.lock','rust-toolchain.toml')]
sources={str(p.relative_to(root)):sha(p) for p in files}
assert not subprocess.check_output(['git','status','--porcelain'])
env=dict(os.environ,CARGO_TARGET_DIR=str(root/'target'),CARGO_PROFILE_DEV_OPT_LEVEL='3')
command=['cargo','build','--locked','-p','geode-core','--example','icem_final_refinement','--no-default-features','--message-format=json']
receipt={'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'source_sha256':sources,'command':command,'platform':platform.platform(),'rustc':subprocess.check_output(['rustc','-Vv'],text=True),'cargo':subprocess.check_output(['cargo','-V'],text=True),'environment_overrides':{k:env[k] for k in ('CARGO_TARGET_DIR','CARGO_PROFILE_DEV_OPT_LEVEL')},'status':'running'}
(out/'build-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
t=time.monotonic()
with (out/'cargo-build.jsonl').open('x') as log,(out/'cargo-build.stderr').open('x') as err:
 run=subprocess.run(command,env=env,stdout=log,stderr=err)
receipt['exit_code']=run.returncode;receipt['elapsed_seconds']=time.monotonic()-t
assert run.returncode==0,(out/'cargo-build.stderr').read_text()[-3000:]
assert sources=={str(p.relative_to(root)):sha(p) for p in files}
rows=[json.loads(l) for l in (out/'cargo-build.jsonl').read_text().splitlines()]
artifacts=[r for r in rows if r.get('reason')=='compiler-artifact' and r.get('target',{}).get('name')=='icem_final_refinement']
assert len(artifacts)==1
binary=pathlib.Path(artifacts[0]['executable']);assert binary.resolve()==root/'target/debug/examples/icem_final_refinement'
receipt.update(status='PASS',binary=str(binary),binary_sha256=sha(binary),source_unchanged=True)
shutil.copy2(binary,out/'icem_final_refinement')
assert sha(out/'icem_final_refinement')==receipt['binary_sha256']
(out/'build-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({k:receipt[k] for k in ('status','source_commit','binary_sha256','elapsed_seconds')}))
