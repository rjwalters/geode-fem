import copy,hashlib,json,math,os,pathlib,subprocess,sys,time
root=pathlib.Path('/Volumes/Stripe/geode-fem/codex-issue-1203-selector');out=pathlib.Path(__file__).resolve().parent
sys.path.insert(0,str(root/'benchmarks/motor_optimization/final_refinement'))
from design_evidence import RegisteredDesigns
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
receipt=json.loads((out/'build-receipt.json').read_text());assert receipt['status']=='PASS'
binary=out/'icem_final_refinement';assert sha(binary)==receipt['binary_sha256']
ref=root/'benchmarks/motor_reference/reference_data.json';starts=root/'benchmarks/motor_optimization/harness/starts.json'
defs=RegisteredDesigns.load(ref,starts,reference_sha256=sha(ref),starts_sha256=sha(starts))
mesh=pathlib.Path('/Volumes/Stripe/geode-fem/codex-issue-1202/benchmarks/motor_reference/geometry/meshes/icem_initial_sector_L2.msh')
anchor=json.loads((root/'benchmarks/motor_optimization/anchor.json').read_text())
assert sha(mesh)==anchor['anchor']['msh_sha256']
requests={};source_ready={}
for s in 'ab':
 source=pathlib.Path('/Volumes/Stripe/scratch-codex-review/issue1203-design-evidence')/(s+'.json')
 (out/(s+'-retained-ready.json')).write_bytes(source.read_bytes())
 retained=json.loads(source.read_text());ready=retained['ready'];source_ready[s]=ready
 provenance={k:retained['checks'][0]['adapted']['settings'][k] for k in ('source_commit','binary_sha256','source_files_sha256')}
 adapted=defs.adapt({'space':s,'evaluator_ready':ready,'anchor':ready['anchor']},{'x':ready['space']['x0']},provenance=provenance)
 requests[s]={'schema':'icem-final-refinement/1','cost_scope':'post_run','space':s,'check':'primary','design_key':adapted['design'].key,'base_settings_sha256':adapted['design'].settings_key,'reference_data_sha256':sha(ref),'reference_mesh_sha256':sha(mesh),'x_bits':adapted['x_bits'],'point_names':adapted['native_point_names'],'point_bits':adapted['native_point_bits']}
summary={'scope':'Bounded post-merge native wiring at theta0, with retained native ready/schema and exact full-design adaptation. No optimizer, main cohort or speedup result. Local debug-profile optimized build; costs are not benchmark performance.','build_receipt_sha256':sha(out/'build-receipt.json'),'input_mesh_sha256':sha(mesh),'cases':[]}
def invoke(name,req):
 path=out/(name+'.request.json');path.write_text(json.dumps(req,indent=2)+'\n')
 command=[str(binary),'--request',str(path),'--mesh',str(mesh),'--out',str(out/name)]
 t=time.monotonic()
 with (out/(name+'.stdout')).open('x') as stdout,(out/(name+'.stderr')).open('x') as stderr:
  done=subprocess.run(command,env=dict(os.environ,RAYON_NUM_THREADS='1',GEODE_NUM_THREADS='1'),stdout=stdout,stderr=stderr,timeout=600)
 result=json.loads((out/name/'result.json').read_text())
 assert result['request_sha256']==sha(path)
 assert result['cost_scope']=='post_run' and result['target_credit_policy']=='preserve_original_common_validation'
 assert result['resources']['cpu_complete'] is True and result['resources']['observed_cpu_seconds']>=0
 summary['cases'].append({'name':name,'command':command,'exit_code':done.returncode,'wall_seconds':time.monotonic()-t,'status':result['status'],'result_sha256':sha(out/name/'result.json')})
 (out/'probe-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
 return done,result
# Refusals do not call FEM. The mutated identifiers are explicitly schema probes.
bad=copy.deepcopy(requests['a']);bad['point_bits'][0]+=1
d,r=invoke('wrong-point',bad);assert d.returncode==2 and r['status']=='refused' and 'point' in r['error']
bad=copy.deepcopy(requests['a']);bad['reference_mesh_sha256']='e'*64
d,r=invoke('wrong-mesh',bad);assert d.returncode==2 and 'hash mismatch' in r['error']
# Adapt a physical nonzero stator offset through the same real ready map.
s='b';retained=json.loads((out/'b-retained-ready.json').read_text());ready=retained['ready']
x=copy.deepcopy(ready['space']['x0']);x[15]=0.0001
provenance={k:retained['checks'][0]['adapted']['settings'][k] for k in ('source_commit','binary_sha256','source_files_sha256')}
a=defs.adapt({'space':s,'evaluator_ready':ready,'anchor':ready['anchor']},{'x':x},provenance=provenance)
bad=copy.deepcopy(requests['b']);bad.update(check='conforming',design_key=a['design'].key,x_bits=a['x_bits'],point_bits=a['native_point_bits'])
d,r=invoke('nonzero-stator',bad);assert d.returncode==2 and r['status']=='unavailable' and 'model_dependent' in r['error']
for s,name in [('a','primary'),('b','primary'),('a','shifted')]:
 req=copy.deepcopy(requests[s]);req['check']=name
 d,r=invoke(s+'-'+name,req);assert d.returncode==0 and r['ok'] is True,r
 v=r['validation'];assert r['point_bits']==req['point_bits'] and r['x_bits']==req['x_bits']
 assert len(v['currents'])==3 and all(len(c['torques'])==20 for c in v['currents'])
 assert all(math.isfinite(t) for c in v['currents'] for t in c['torques'])
 assert math.isclose(v['F'],sum(c['std2'] for c in v['currents']),rel_tol=1e-14)
 if name=='primary':
  expected=anchor['validation_space_'+s]
  delta=max(abs(a-b) for c,e in zip(v['currents'],expected['currents']) for a,b in zip(c['torques'],e['torques']))
  assert delta<=1e-9,delta
  assert abs(v['F']-anchor['anchor']['F0'])<=1e-9*anchor['anchor']['F0']
  summary['cases'][-1]['max_anchor_torque_difference']=delta
 else: assert r['config']['angles_deg']==[i+.5 for i in range(20)]
 summary['cases'][-1]['waveform_samples']=60
 (out/'probe-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
summary['status']='PASS';summary['limitations']=['L3, g40, tight, withheld and successful fresh conforming execution not yet exercised by this bounded smoke.','Full closed-study driver, runtime/source/capture authentication, cohort execution and independent review remain pending.']
assert sha(binary)==receipt['binary_sha256']
(out/'probe-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({'status':'PASS','cases':len(summary['cases']),'new_forward_sweeps':9,'new_torque_samples':180}))
