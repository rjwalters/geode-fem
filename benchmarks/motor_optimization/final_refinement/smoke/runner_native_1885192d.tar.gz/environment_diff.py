from pathlib import Path
import json,sys,os
repo=Path('/Volumes/Stripe/geode-fem/codex-issue-1203-selector');sys.path.insert(0,str(repo/'benchmarks/motor_optimization/final_refinement'))
import refinement_environment
root=Path('/Volumes/Stripe/scratch-codex-review/issue1203-environment');p=json.loads((root/'preparation-receipt.json').read_text())
executor=Path('/Volumes/Stripe/geode-fem/codex-issue-1203-executor-build');os.chdir(executor)
args=dict(bundle_root=root/'inputs',bundle_sha256=p['sha256'],build_root=Path('/Volumes/Stripe/scratch-codex-review/issue1203-paired-build-1c6784e7/executors'),build_sha256='62a4592a4e1a7f53acde1ff7bdd8aacdd7b3650ebdc5b684b62710a93a93baed',repo=executor,executor_commit='1c6784e7e1fc8fe0564b1d793a6c4061588028f5')
new=refinement_environment.capture(**args);old=json.loads((root/'environment.json').read_text())
changes=[k for k,v in new['runtime'].items() if v!=old['runtime'].get(k)]
Path(__file__).with_name('environment-diff.json').write_text(json.dumps({'changed_runtime_fields':changes,'bindings_equal':new['bindings']==old['bindings']},indent=2)+'\n')
print(json.dumps({'changed_runtime_fields':changes,'bindings_equal':new['bindings']==old['bindings']}))
