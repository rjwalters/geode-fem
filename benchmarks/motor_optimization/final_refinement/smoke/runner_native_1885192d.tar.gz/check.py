from pathlib import Path
import gzip,hashlib,importlib,json,os,sys,tarfile
repo=Path('/Volumes/Stripe/geode-fem/codex-issue-1203-selector');here=repo/'benchmarks/motor_optimization/final_refinement'
sys.path.insert(0,str(here))
import refinement_run,refinement_environment,producer_source
root=Path(__file__).resolve().parent;inputs=root/'inputs';inputs.mkdir()
archive=here/'smoke/native_refinement_63b3e3d8.tar.gz'
assert hashlib.sha256(archive.read_bytes()).hexdigest()=='eac07e2ce0a71d45b77e7c7c33cf856206563272f9d63515d36690c5209698bc'
with tarfile.open(archive) as tar:raw=tar.extractfile('a-primary.request.json').read()
request=json.loads(raw);(inputs/'primary.json').write_bytes(raw)
from mesh_test_support import mesh_bytes
mesh=mesh_bytes('00a7eb6f88bd8fdf22e8ad0b406d4889a68c2d269fc3216ff81f255cddb71cf5')
assert hashlib.sha256(mesh).hexdigest()==request['reference_mesh_sha256']=='00a7eb6f88bd8fdf22e8ad0b406d4889a68c2d269fc3216ff81f255cddb71cf5'
(inputs/'inputs').mkdir();(inputs/'inputs/L2.msh').write_bytes(mesh)
key=request['design_key'];space=request['space']
(inputs/'geometry.json').write_text(json.dumps(dict(id=1,op='geometry',x_bits=request['x_bits']))+'\n')
bundle={'geometry':[dict(design_key=key,space=space,request_file='geometry.json')],
 'jobs':[dict(design_key=key,space=space,job_id=key+'/primary',request_file='primary.json',mesh_file='inputs/L2.msh',output_directory='results/'+key+'/primary')]}
(root/'smoke-plan.json').write_text(json.dumps(bundle,indent=2)+'\n')
executor=Path('/Volumes/Stripe/geode-fem/codex-issue-1203-executor-build');os.chdir(executor)
envroot=Path('/Volumes/Stripe/scratch-codex-review/issue1203-environment')
prepared=json.loads((envroot/'preparation-receipt.json').read_text());receipt=json.loads((envroot/'environment-receipt.json').read_text())
args=dict(bundle_root=envroot/'inputs',bundle_sha256=prepared['sha256'],
 build_root=Path('/Volumes/Stripe/scratch-codex-review/issue1203-paired-build-1c6784e7/executors'),
 build_sha256='62a4592a4e1a7f53acde1ff7bdd8aacdd7b3650ebdc5b684b62710a93a93baed',repo=executor,executor_commit='1c6784e7e1fc8fe0564b1d793a6c4061588028f5')
proof=refinement_environment.verify(envroot/'environment.json',sha256=receipt['sha256'],**args)
(root/'environment-before.json').write_text(json.dumps(proof,indent=2)+'\n')
executables={n:dict(path=args['build_root']/n/n,sha256=p['binary_sha256']) for n,p in proof['bindings']['build']['executables'].items()}
with producer_source.committed_modules(executor,args['executor_commit'],refinement_run.MODULES):
 modules={name:importlib.import_module(name) for name in refinement_run.MODULES}
 journal=modules['session_journal'].Journal(root/'execution',{'scope':'Bounded native wiring smoke, not a selected main cohort','source_commit':args['executor_commit']})
 try:
  with modules['interruption'].StopSignals() as signals:
   rows=refinement_run._execute(root/'execution',inputs,bundle,executables,modules,journal,refinement_environment.execution_env(),lambda:signals.requested)
  journal.emit('refinement_execution_completed',requests=len(rows))
 finally:journal.close()
(root/'rows.json').write_text(json.dumps(rows,indent=2)+'\n')
after=refinement_environment.verify(envroot/'environment.json',sha256=receipt['sha256'],**args)
(root/'environment-after.json').write_text(json.dumps(after,indent=2)+'\n')
geometry=json.loads((root/'execution/geometry'/key/'geometry.json').read_text())
native=json.loads((root/'execution/results'/key/'primary/native/result.json').read_text())
assert geometry['ok'] and native['ok'] and native['request']==request
summary={'status':'PASS','requests':2,'returncodes':[r['returncode'] for r in rows],
 'source_commit':args['executor_commit'],'request_sha256':hashlib.sha256(raw).hexdigest(),
 'mesh_sha256':request['reference_mesh_sha256'],'native_result_sha256':producer_source.digest(root/'execution/results'/key/'primary/native/result.json'),
 'geometry_sha256':producer_source.digest(root/'execution/geometry'/key/'geometry.json'),
 'tool_sources':refinement_run.tool_sources(),'scope':'Real geometry and single primary native request through the owned runner primitive, using retained reference inputs. Environment gate verified separately against synthetic selection. Not a full prepared-cohort run, not main-study selection or speedup evidence. Process absence checked after this script exits.','can_report_main':False}
(root/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps({k:v for k,v in summary.items() if k!='tool_sources'}))
