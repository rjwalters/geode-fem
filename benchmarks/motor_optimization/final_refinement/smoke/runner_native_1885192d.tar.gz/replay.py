from pathlib import Path
import importlib,json,sys
repo=Path(sys.argv[1]).resolve();here=repo/'benchmarks/motor_optimization/final_refinement';sys.path.insert(0,str(here))
import refinement_run,producer_source,native_results,test_native_results
root=Path(__file__).resolve().parent
summary=json.loads((root/'summary.json').read_text());rows=json.loads((root/'rows.json').read_text());bundle=json.loads((root/'smoke-plan.json').read_text())
with producer_source.committed_modules(repo,summary['source_commit'],refinement_run.MODULES):
 retained=json.loads((root/'process-verification.json').read_text());table=retained['table'];host=retained['host']
 proof=importlib.import_module('process_verification').verify(root/'execution',observe=lambda:table,host=lambda:host)
 assert proof['processes_stopped'],proof['issues']
 comparable=lambda p:{k:v for k,v in p.items() if k not in ('source','observed_time')}
 assert comparable(proof)==comparable(retained['report'])
 events=importlib.import_module('session_journal').read_events(root/'execution/events.jsonl')['events']
 refinement_run._verify_rows(root/'execution',{'rows':rows},bundle,events)
fixture=test_native_results.NativeResultsTests;fixture.setUpClass()
try:
 key=fixture.keys['a','theta0'];job=key+'/primary'
 path=root/'execution/results'/key/'primary/native/result.json';geometry=root/'execution/geometry'/key/'geometry.json'
 artifact=dict(path=path,sha256=producer_source.digest(path),geometry=dict(path=geometry,sha256=producer_source.digest(geometry),space='a'),meshes={m['sha256']:m['path'] for m in fixture.meshes.values()})
 provenance=dict(source_commit=summary['source_commit'],binary_sha256='a96ab99cf18540a3028d463e6cd171c06959a6fada4d10e215aeebc376ec4f11',common_physics_sha256=fixture.definitions.reference_sha256)
 report=native_results.report(fixture.selection,fixture.designs,fixture.definitions,fixture.meshes,{job:artifact},provenance=provenance,geometry_definitions=fixture.geometry_definitions)
 assert report['reductions'][job]['status']=='ok'
 row=report['observations'][job]
 result=dict(status='PASS',native_requests=1,geometry_queries=1,torque_samples=sum(len(c['torques']) for c in row['currents']),processes_stopped=True,adapter_status=report['reductions'][job]['status'],scope='New real native outputs validated in an explicitly synthetic selection context. All other planned checks are missing; no main cohort, optimization, attainment or performance evidence.',can_report_main=False)
 assert result==json.loads((root/'verification-summary.json').read_text());print(json.dumps(result))
finally:fixture.tearDownClass()
