"""Theta0 numerical stability only; no optimization/target credit claims."""
import hashlib,json,math,pathlib,struct
out=pathlib.Path(__file__).resolve().parent;root=pathlib.Path('/Volumes/Stripe/geode-fem/codex-issue-1203-selector');prior=out.with_name('issue1203-native-refinement')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
files={'primary':prior/'a-primary/result.json','shifted':prior/'a-shifted/result.json',**{c:out/f'a-theta0-{c}/result.json' for c in ('g40','tight','withheld','L3')}}
rows={name:json.loads(path.read_text()) for name,path in files.items()}
base=rows['primary'];F0=base['validation']['F'];mean0=base['validation']['full_current_mean']
report={'scope':'Theta0 numerical sensitivity of the new native wiring. No selected main candidate, main target credit or speedup evidence. Withheld-current sums are kept separate from the registered objective.','input_sha256':{name:sha(p) for name,p in files.items()},'reference_comparisons':{},'checks':{}}
for name,row in rows.items():
 assert row['ok'] is True and row['point_bits']==base['point_bits']
 v=row['validation'];cfg=row['config'];shared=[a for a in cfg['angles_deg'] if a in base['config']['angles_deg']]
 comparable=cfg['fractions']==base['config']['fractions'];record={'config':cfg,'sum_variances':v['F'],'currents':[]}
 if comparable:
  record.update(F_relative_change=(v['F']-F0)/F0,full_mean_relative_change=(v['full_current_mean']-mean0)/mean0)
 for i,c in enumerate(v['currents']):
  stats={'fraction':c['fraction'],'mean':c['mean'],'std':c['std'],'samples':len(c['torques'])}
  if comparable:
   other=base['validation']['currents'][i];stats['mean_difference']=c['mean']-other['mean'];stats['std_difference']=c['std']-other['std']
   delta=[c['torques'][cfg['angles_deg'].index(a)]-other['torques'][base['config']['angles_deg'].index(a)] for a in shared]
   stats['same_angle_max_abs_torque_difference']=max(map(abs,delta)) if delta else None
  record['currents'].append(stats)
 if not comparable:record['registered_objective']=False
 report['checks'][name]=record
for name,file in [('g40','theta0_nurbs_L2_g40.json'),('L3','theta0_nurbs_L3_L3_space_a.json')]:
 p=root/'benchmarks/motor_optimization/runs'/file;old=json.loads(p.read_text())['validation'];new=rows[name]['validation']
 assert old['msh_sha256']==new['msh_sha256']
 assert old['config']['angles_deg']==new['config']['angles_deg'] and old['config']['fractions']==new['config']['fractions']
 delta=max(abs(a-b) for l,r in zip(old['currents'],new['currents']) for a,b in zip(l['torques'],r['torques']))
 bitwise=all(struct.pack('>d',a)==struct.pack('>d',b) for l,r in zip(old['currents'],new['currents']) for a,b in zip(l['torques'],r['torques']))
 assert delta<=1e-9 and bitwise,(name,delta)
 report['reference_comparisons'][name]={'reference_file':file,'reference_sha256':sha(p),'max_abs_torque_difference':delta,'waveforms_bitwise_equal':bitwise,'F_difference':new['F']-old['F']}
anchor_path=root/'benchmarks/motor_optimization/anchor.json'
anchor=json.loads(anchor_path.read_text())
for space in 'ab':
 p=prior/f'{space}-primary/result.json';new=json.loads(p.read_text())['validation'];old=anchor['validation_space_'+space]
 bitwise=all(struct.pack('>d',a)==struct.pack('>d',b) for l,r in zip(old['currents'],new['currents']) for a,b in zip(l['torques'],r['torques']))
 assert bitwise
 report['reference_comparisons']['primary_'+space]={'reference_file':'anchor.json','reference_sha256':sha(anchor_path),'native_raw_sha256':sha(p),'waveforms_bitwise_equal':True}
report['moved_start_checks']={}
for space in 'ab':
 p=out/f'{space}-lhs1-primary/result.json';r=json.loads(p.read_text());v=r['validation']
 report['moved_start_checks'][space]={'raw_sha256':sha(p),'F':v['F'],'mean_full':v['full_current_mean'],'mesh_kind':v['mesh']['kind'],'reference_mean_floor':1.0025*mean0,'mean_floor_pass':v['full_current_mean']>=1.0025*mean0,'scope':'Post-run wiring check at a registered starting point; original run credit/budget not evaluated.'}
(out/'theta0-stability.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
print(json.dumps({'reference_comparisons':report['reference_comparisons'],'relative_F_changes':{k:v.get('F_relative_change') for k,v in report['checks'].items()}}))
