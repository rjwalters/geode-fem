import copy,hashlib,json,math,os,pathlib,subprocess,sys,time
root=pathlib.Path('/Volumes/Stripe/geode-fem/codex-issue-1203-selector');out=pathlib.Path(__file__).resolve().parent
prior=out.with_name('issue1203-native-refinement')
sys.path.insert(0,str(root/'benchmarks/motor_optimization/final_refinement'))
from design_evidence import RegisteredDesigns
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
receipt=json.loads((prior/'build-receipt.json').read_text());binary=prior/'icem_final_refinement'
assert receipt['status']=='PASS' and sha(binary)==receipt['binary_sha256']
for name,digest in receipt['source_sha256'].items(): assert sha(root/name)==digest,name
(out/'build-receipt.json').write_bytes((prior/'build-receipt.json').read_bytes())
ref=root/'benchmarks/motor_reference/reference_data.json';starts=root/'benchmarks/motor_optimization/harness/starts.json'
defs=RegisteredDesigns.load(ref,starts,reference_sha256=sha(ref),starts_sha256=sha(starts))
mesh2=pathlib.Path('/Volumes/Stripe/geode-fem/codex-issue-1202/benchmarks/motor_reference/geometry/meshes/icem_initial_sector_L2.msh')
mesh3=out/'l3-mesh/icem_initial_sector_L3.msh'
registered=json.loads((root/'benchmarks/motor_reference/geometry/meshes/icem_initial_sector_L3_report.json').read_text())
assert sha(mesh3)==registered['msh_sha256']
(out/'registered-L3-report.json').write_text(json.dumps(registered,indent=2)+'\n')
summary={'scope':'Remaining native refinement settings and moved-point wiring only; no optimizer/main cohort/speedup result. Costs from a local optimized dev binary are not performance claims.','source_commit':receipt['source_commit'],'binary_sha256':sha(binary),'registered_L3_mesh_reproduced_bitwise':True,'L3_mesh_sha256':sha(mesh3),'cases':[]}
def make_request(s,start,check,mesh):
 p=prior/(s+'-retained-ready.json');(out/p.name).write_bytes(p.read_bytes());old=json.loads(p.read_text());ready=old['ready']
 provenance={k:old['checks'][0]['adapted']['settings'][k] for k in ('source_commit','binary_sha256','source_files_sha256')}
 x=json.loads(starts.read_text())['starts'][start][s]
 d=defs.adapt({'space':s,'evaluator_ready':ready,'anchor':ready['anchor']},{'x':x},provenance=provenance)
 return {'schema':'icem-final-refinement/1','cost_scope':'post_run','space':s,'check':check,'design_key':d['design'].key,'base_settings_sha256':d['design'].settings_key,'reference_data_sha256':sha(ref),'reference_mesh_sha256':sha(mesh),'x_bits':d['x_bits'],'point_names':d['native_point_names'],'point_bits':d['native_point_bits']}
for s,start,check in [('a','theta0','g40'),('a','theta0','tight'),('a','theta0','withheld'),('a','lhs1','primary'),('b','lhs1','primary'),('a','theta0','L3')]:
 mesh=mesh3 if check=='L3' else mesh2;name=f'{s}-{start}-{check}';req=make_request(s,start,check,mesh)
 path=out/(name+'.request.json');path.write_text(json.dumps(req,indent=2)+'\n')
 command=[str(binary),'--request',str(path),'--mesh',str(mesh),'--out',str(out/name)]
 summary['active_case']=name;(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
 t=time.monotonic()
 with (out/(name+'.stdout')).open('x') as stdout,(out/(name+'.stderr')).open('x') as stderr:
  done=subprocess.run(command,env=dict(os.environ,RAYON_NUM_THREADS='1',GEODE_NUM_THREADS='1'),stdout=stdout,stderr=stderr,timeout=900)
 result=json.loads((out/name/'result.json').read_text());row={'name':name,'command':command,'exit_code':done.returncode,'wall_seconds':time.monotonic()-t,'status':result['status'],'result_sha256':sha(out/name/'result.json')}
 summary['cases'].append(row);(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
 assert done.returncode==0 and result['ok'] is True,result
 assert result['cost_scope']=='post_run' and result['target_credit_policy']=='preserve_original_common_validation'
 assert result['request_sha256']==sha(path) and result['point_bits']==req['point_bits'] and result['x_bits']==req['x_bits']
 assert result['resources']['cpu_complete'] is True
 val=result['validation'];cfg=result['config'];angles=[i*.5 for i in range(40)] if check=='g40' else [float(i) for i in range(20)]
 fractions=[.25,.75] if check=='withheld' else [0.,.5,1.]
 assert cfg['level']==(3 if check=='L3' else 2) and cfg['mode']=='h93' and cfg['angles_deg']==angles and cfg['fractions']==fractions
 assert cfg['newton_rel_tol']==(1e-12 if check=='tight' else 1e-8)
 assert [c['fraction'] for c in val['currents']]==fractions
 assert all(len(c['torques'])==len(angles) and all(math.isfinite(t) for t in c['torques']) for c in val['currents'])
 assert math.isclose(val['F'],sum(c['std2'] for c in val['currents']),rel_tol=1e-14)
 row.update(waveform_samples=len(angles)*len(fractions),mesh_kind=val['mesh']['kind'],objective=val['F'])
 if start!='theta0':assert val['mesh']['kind'] in ('moved','fresh')
 if check=='withheld':assert val['full_current_mean'] is None
 (out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(row),flush=True)
for name,digest in receipt['source_sha256'].items():assert sha(root/name)==digest,name
assert sha(binary)==receipt['binary_sha256']
summary.pop('active_case');summary.update(status='PASS',waveform_samples=sum(r['waveform_samples'] for r in summary['cases']),limitations=['Wiring coverage only; complete capture authentication and frozen main-cohort driver remain pending.','Selected main candidates and their own matched references have not been refined.'])
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({'status':'PASS','waveform_samples':summary['waveform_samples']}))
