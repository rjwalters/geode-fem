import hashlib,json,pathlib,tarfile,subprocess
root=pathlib.Path('/Volumes/Stripe/geode-fem/codex-issue-1203-selector');out=pathlib.Path(__file__).resolve().parent;here=root/'benchmarks/motor_optimization/final_refinement'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
probe=json.loads((out/'summary.json').read_text());stability=json.loads((out/'theta0-stability.json').read_text());assert probe['status']=='PASS'
source_names=['benchmarks/motor_reference/geometry/build_sector_mesh.py','benchmarks/motor_reference/geometry/geopdes_nurbs.py','benchmarks/motor_reference/sources.json','benchmarks/motor_reference/conventions.json','benchmarks/motor_reference/reference_data.json','benchmarks/motor_optimization/harness/starts.json']
sources={name:sha(root/name) for name in source_names}
for name,digest in sources.items():assert hashlib.sha256(subprocess.check_output(['git','show',probe['source_commit']+':'+name],cwd=root)).hexdigest()==digest
(out/'input-source-hashes.json').write_text(json.dumps({'source_commit':probe['source_commit'],'source_sha256':sources,'L3_generation_command':['uv','run','-q','--with','numpy==2.5.4','--with','gmsh==4.15.2','python','-I','benchmarks/motor_reference/geometry/build_sector_mesh.py','--levels','3','--out',str(out/'l3-mesh')]},indent=2)+'\n')
for file in ['theta0_nurbs_L2_g40.json','theta0_nurbs_L3_L3_space_a.json']:
 (out/('reference-'+file)).write_bytes((root/'benchmarks/motor_optimization/runs'/file).read_bytes())
prior=out.with_name('issue1203-native-refinement')
(out/'reference-anchor.json').write_bytes((root/'benchmarks/motor_optimization/anchor.json').read_bytes())
(out/'reference-native-b-primary.json').write_bytes((prior/'b-primary/result.json').read_bytes())
for name in ('primary','shifted'):(out/('reference-native-'+name+'.json')).write_bytes((prior/f'a-{name}/result.json').read_bytes())
files=[p for p in sorted(out.rglob('*')) if p.is_file() and p.name!='manifest.json'];manifest={str(p.relative_to(out)):sha(p) for p in files};(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
archive=here/'smoke/native_matrix_63b3e3d8.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
 for p in files+[out/'manifest.json']:tar.add(p,arcname=str(p.relative_to(out)),recursive=False)
with tarfile.open(archive,'r:gz') as tar:
 for name,digest in manifest.items():assert hashlib.sha256(tar.extractfile(name).read()).hexdigest()==digest
summary={'schema':1,'status':'PASS','scope':probe['scope'],'source_commit':probe['source_commit'],'binary_sha256':probe['binary_sha256'],'matrix_probe':probe,'theta0_stability':stability,'input_source_sha256':sources,'archive':{'file':str(archive.relative_to(here)),'sha256':sha(archive),'bytes':archive.stat().st_size,'files':len(files)+1,'each_payload_member_verified':True},'scope_limits':['These are theta0 and registered-start wiring runs, not the selected main-study cohort.','No timing, optimizer advantage or target-credit conclusion follows from local smoke costs.','Full closed-study capture/authentication/selection/native-result driver and independent review remain pending.','Conforming new-mesh execution is covered by native-execution-checks.json; this increment changes no runner source.']}
(here/'native-matrix-checks.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({'status':'PASS','waveform_samples':probe['waveform_samples'],'archive':summary['archive']}))
