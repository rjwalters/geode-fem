import base64,datetime,hashlib,json,pathlib
root=pathlib.Path('/home/ubuntu/exp2-main/main');raw=(root/'bindings.json').read_bytes()
assert hashlib.sha256(raw).hexdigest()=='4dac96a80c22c6ff35981124afdbd268b8049231682e6ab1d3da32cb66815d89'
b=json.loads(raw);files={'bindings.json':raw}
for name,digest in b['files'].items():
 assert pathlib.Path(name).name==name
 data=(root/name).read_bytes();assert hashlib.sha256(data).hexdigest()==digest;files[name]=data
assert all((root/name).read_bytes()==data for name,data in files.items())
print(json.dumps({'scope':'Immutable setup files from a live study; not closure or optimizer evidence.',
 'observed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'files':{name:{'sha256':hashlib.sha256(data).hexdigest(),'base64':base64.b64encode(data).decode()} for name,data in files.items()}}))
