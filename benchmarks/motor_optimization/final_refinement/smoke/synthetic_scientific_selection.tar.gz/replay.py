from pathlib import Path
import json,sys
root=Path(__file__).resolve().parent;repo=Path(sys.argv[1]).resolve()
sys.path.insert(0,str(repo/'benchmarks/motor_optimization/final_refinement'))
import study_selection
ids=json.loads((root/'identities.json').read_text())
result=study_selection.load(root/'capture',git_repo=repo,**{k:v for k,v in ids.items() if k!='scope'})
expected=json.loads((root/'selection.json').read_text())
for key in ('selection','plan','designs'):
 assert result[key]==expected[key],key
assert len(result['attempts'])==100 and result['can_launch'] is False
print(json.dumps({'scope':ids['scope'],'status':'PASS','attempts':100,'designs':len(result['designs']),'checks':len(result['plan']['jobs'])}))
