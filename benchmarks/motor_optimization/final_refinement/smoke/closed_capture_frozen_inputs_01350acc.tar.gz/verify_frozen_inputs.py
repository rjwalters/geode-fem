"""Replay the frozen declaration/Git comparison; never query or close a session."""
import base64,hashlib,json,pathlib,sys
root=pathlib.Path(sys.argv[1]).resolve();out=pathlib.Path(__file__).resolve().parent
sys.path.insert(0,str(root/'benchmarks/motor_optimization/final_refinement'))
import producer_source
probe=json.loads((out/'frozen-input-probe.json').read_text())
for name,item in probe['files'].items():
 raw=base64.b64decode(item['base64'])
 assert hashlib.sha256(raw).hexdigest()==item['sha256']
 assert (out/name).read_bytes()==raw
bindings=json.loads((out/'bindings.json').read_text())
assert bindings['files']['recovery-inputs.json']==probe['files']['recovery-inputs.json']['sha256']
assert probe['ready']['bindings_sha256']==probe['files']['bindings.json']['sha256']
inputs=json.loads((out/'recovery-inputs.json').read_text())
verified=producer_source.verify(root,inputs['source'],reviewed_commit='9486a9da58beeca91968d4d3608f06b998abff45',check_worktree=False)
print(json.dumps({'status':'PASS','source_files':len(verified['files']),
 'scope':'Frozen source declaration/Git comparison only; not current remote runtime or closed-study authentication.'}))
