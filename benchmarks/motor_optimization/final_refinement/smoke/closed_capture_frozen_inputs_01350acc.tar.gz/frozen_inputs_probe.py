import base64,datetime,hashlib,json,pathlib
root=pathlib.Path('/home/ubuntu/exp2-main/main')
files={name:(root/name).read_bytes() for name in ('bindings.json','recovery-inputs.json')}
b=json.loads(files['bindings.json'])
assert hashlib.sha256(files['recovery-inputs.json']).hexdigest()==b['files']['recovery-inputs.json']
ready=[]
for line in (root/'events.jsonl').read_bytes().splitlines(keepends=True):
 if not line.endswith(b'\n'):continue
 event=json.loads(line)
 if event['kind']=='session_ready':ready.append(event)
assert len(ready)==1
assert ready[0]['bindings_sha256']==hashlib.sha256(files['bindings.json']).hexdigest()
assert all((root/name).read_bytes()==raw for name,raw in files.items())
print(json.dumps({'scope':'Read-only live frozen inputs; no closure, process absence, runtime re-verification or scientific eligibility claimed.',
 'observed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source':str(root),'ready':ready[0],
 'files':{name:{'sha256':hashlib.sha256(raw).hexdigest(),'base64':base64.b64encode(raw).decode()} for name,raw in files.items()}}))
