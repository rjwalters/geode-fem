"""Portable read-only replay of retained real build and process observations."""
from pathlib import Path
import importlib,json,sys
root=Path(__file__).resolve().parent;repo=Path(sys.argv[1]).resolve()
sys.path.insert(0,str(repo/'benchmarks/motor_optimization/final_refinement'))
import refinement_build,producer_source
receipt=json.loads((root/'receipt.json').read_text());commit=receipt['source_commit']
proof=refinement_build.verify(root/'executors',manifest_sha256=receipt['sha256'],git_repo=repo,
                              reviewed_commit=commit,check_worktree=False)
evidence=json.loads((root/'process-verification.json').read_text())
with producer_source.committed_modules(repo,commit,('process_identity','session_journal','recovery_inventory','process_verification')):
 verifier=importlib.import_module('process_verification')
 for name,recorded in evidence['reports'].items():
  actual=verifier.verify(root/'executors'/name,observe=lambda:evidence['table'],host=lambda:evidence['host'])
  comparable=lambda v:{k:x for k,x in v.items() if k not in ('source','observed_time')}
  assert actual['processes_stopped'] is True and comparable(actual)==comparable(recorded)
print(json.dumps({'status':'PASS','source_commit':commit,'source_files':len(proof['source']['files']),
 'manifest_sha256':receipt['sha256'],'binary_sha256':{n:p['binary_sha256'] for n,p in proof['executables'].items()},
 'scope':'Retained actual local release-build/source/process evidence; archived process observations only, no current runtime or process-state claim, and no FEM execution.',
 'can_launch':False}))
