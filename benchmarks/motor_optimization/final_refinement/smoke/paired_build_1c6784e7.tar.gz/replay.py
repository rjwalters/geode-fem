"""Replay historical build digest/source/process records, without binary bytes."""
from pathlib import Path
import importlib,json,sys,hashlib
root=Path(__file__).resolve().parent;repo=Path(sys.argv[1]).resolve()
sys.path.insert(0,str(repo/'benchmarks/motor_optimization/final_refinement'))
import refinement_build,producer_source
from closed_capture import census
receipt=json.loads((root/'receipt.json').read_text());commit=receipt['source_commit']
raw=(root/'executors/executors.json').read_bytes()
assert hashlib.sha256(raw).hexdigest()==receipt['sha256']
metadata=json.loads(raw)
producer_source.verify(repo,metadata['source'],reviewed_commit=commit,check_worktree=False)
omitted=json.loads((root/'omitted-payloads.json').read_text())['files']
assert set(omitted)=={'executors/'+n+'/'+n for n in refinement_build.EXAMPLES}
observed=census(root/'executors');observed['files'].pop('executors.json')
for name in refinement_build.EXAMPLES:
 key=name+'/'+name;item=omitted['executors/'+key];original=metadata['inventory']['files'][key]
 assert item=={'sha256':original['sha256'],'bytes':original['size']}
 assert not (root/'executors'/key).exists()
 observed['files'][key]=original
 build=json.loads((root/'executors'/name/'build-receipt.json').read_text())
 assert build['status']=='recorded' and build['source']==metadata['source']
 assert build['binary']['sha256']==item['sha256']==metadata['receipts'][name]['binary_sha256']
 assert hashlib.sha256((root/'executors'/name/'build-receipt.json').read_bytes()).hexdigest()==metadata['receipts'][name]['sha256']
assert observed==metadata['inventory']
with refinement_build.api(repo,commit) as (api,hashes):
 assert metadata['function_source_sha256']==hashes
evidence=json.loads((root/'process-verification.json').read_text())
with producer_source.committed_modules(repo,commit,('process_identity','session_journal','recovery_inventory','process_verification')):
 verifier=importlib.import_module('process_verification')
 for name,recorded in evidence['reports'].items():
  actual=verifier.verify(root/'executors'/name,observe=lambda:evidence['table'],host=lambda:evidence['host'])
  comparable=lambda v:{k:x for k,x in v.items() if k not in ('source','observed_time')}
  assert actual['processes_stopped'] is True and comparable(actual)==comparable(recorded)
print(json.dumps({'status':'PASS','source_commit':commit,'source_files':len(metadata['source']['files']),
 'manifest_sha256':receipt['sha256'],'binary_sha256':{n:metadata['receipts'][n]['binary_sha256'] for n in refinement_build.EXAMPLES},
 'binary_bytes_verified':False,
 'scope':'Historical digest/source/process-record consistency only. Binary payloads omitted; no executable authentication, current process-state claim or FEM execution.',
 'can_launch':False}))
