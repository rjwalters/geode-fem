"""Historical verifier source retained as verify-original.py.txt; use replay.py for digest-only replay."""
raise SystemExit("Binary bytes omitted: regenerate a paired build before production verification")
