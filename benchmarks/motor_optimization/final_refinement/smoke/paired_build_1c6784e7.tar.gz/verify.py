"""Verify actual paired build receipts after the compiler owner exits."""
from pathlib import Path
import importlib,json,sys
root=Path(__file__).resolve().parent
repo=Path('/Volumes/Stripe/geode-fem/codex-issue-1203-executor-build')
sys.path.insert(0,str(repo/'benchmarks/motor_optimization/final_refinement'))
import refinement_build,producer_source
receipt=json.loads((root/'receipt.json').read_text());commit=receipt['source_commit']
proof=refinement_build.verify(root/'executors',manifest_sha256=receipt['sha256'],git_repo=repo,reviewed_commit=commit)
with producer_source.committed_modules(repo,commit,('process_identity','session_journal','recovery_inventory','process_verification')):
 identity=importlib.import_module('process_identity');verifier=importlib.import_module('process_verification')
 table=identity.table();host=identity.host()
 observations={name:verifier.verify(root/'executors'/name,observe=lambda:table,host=lambda:host) for name in refinement_build.EXAMPLES}
 assert all(v['processes_stopped'] is True and not v['issues'] for v in observations.values())
(root/'process-verification.json').write_text(json.dumps({'table':table,'host':host,'reports':observations},indent=2)+'\n')
(root/'verification.json').write_text(json.dumps(proof,indent=2)+'\n')
print(json.dumps({'verified':proof['verified'],'worktree_checked':proof['worktree_checked'],
 'source_commit':commit,'source_files':len(proof['source']['files']),'manifest_sha256':receipt['sha256'],
 'binary_sha256':{n:p['binary_sha256'] for n,p in proof['executables'].items()},
 'recorded_build_processes_stopped':all(v['processes_stopped'] for v in observations.values()),'can_launch':False},indent=2))
