import base64,datetime,hashlib,json,pathlib
root=pathlib.Path('/home/ubuntu/exp2-main/main')
binding=(root/'bindings.json').read_bytes()
assert hashlib.sha256(binding).hexdigest()=='4dac96a80c22c6ff35981124afdbd268b8049231682e6ab1d3da32cb66815d89'
raw=(root/'events.jsonl').read_bytes();lines=raw.splitlines(keepends=True);events=[];prefix=b''
for line in lines:
 if not line.endswith(b'\n'):break
 event=json.loads(line);events.append(event);prefix+=line
 if event['kind']=='attempt_finished' and event['result'].get('status')=='ran':break
else:raise RuntimeError('no terminal trace')
terminal=events[-1];assert terminal['kind']=='attempt_finished'
name=terminal['result']['trace'];assert pathlib.Path(name).name==name
trace=(root/name).read_bytes();assert len(trace)<50*1024*1024
assert hashlib.sha256(trace).hexdigest()==terminal['result']['trace_sha256']
assert (root/'events.jsonl').read_bytes()[:len(prefix)]==prefix and (root/name).read_bytes()==trace
files={'bindings.json':binding,'events-prefix.jsonl':prefix,name:trace}
print(json.dumps({'scope':'First parent-finalized trace from a still-running main study. Partial schema evidence only; no closure or selection.',
 'observed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'trace':name,
 'terminal_sequence':terminal['sequence'],'files':{n:{'sha256':hashlib.sha256(v).hexdigest(),'base64':base64.b64encode(v).decode()} for n,v in files.items()}}))
