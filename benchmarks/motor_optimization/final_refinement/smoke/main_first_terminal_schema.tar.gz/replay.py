"""Read-only schema replay of one finalized trace, not full-cohort selection."""
import base64,gzip,hashlib,importlib,json,sys
from pathlib import Path
repo=Path(sys.argv[1]).resolve();root=Path(__file__).resolve().parent
sys.path.insert(0,str(repo/'benchmarks/motor_optimization/final_refinement'))
import producer_source,setup_evidence,study_selection,trace_archive,validation_evidence
from design_evidence import bits
value=trace_archive._json((root/'remote-records.json').read_bytes())
raws={n:base64.b64decode(v['base64']) for n,v in value['files'].items()}
for n,raw in raws.items():assert hashlib.sha256(raw).hexdigest()==value['files'][n]['sha256']
bindings=trace_archive._json(raws['bindings.json'])
assert hashlib.sha256(raws['bindings.json']).hexdigest()=='4dac96a80c22c6ff35981124afdbd268b8049231682e6ab1d3da32cb66815d89'
events=trace_archive._events(raws['events-prefix.jsonl']);terminal=events[-1]
ready_events=[e for e in events if e['kind']=='session_ready']
assert len(ready_events)==1 and ready_events[0]['bindings_sha256']==hashlib.sha256(raws['bindings.json']).hexdigest()
assert terminal['kind']=='attempt_finished' and terminal['sequence']==value['terminal_sequence']
aid=terminal['attempt_id'];created=next(e for e in events if e['kind']=='attempt_created' and e['sequence']==aid)
dispatch=next(e for e in events if e['kind']=='attempt_dispatched' and e['attempt_id']==aid)
name=terminal['result']['trace'];assert name==dispatch['trace']==value['trace']
assert terminal['result']['trace_sha256']==value['files'][name]['sha256']
setup_root=root/'setup'
frozen=trace_archive._json((setup_root/'recovery-inputs.json').read_bytes())
records={'bindings.json':bindings}
for n in ('session.json','anchor_preflight.json','start_preflight.json','calibration_primary.json','calibration_secondary.json'):
 raw=(setup_root/n).read_bytes();assert hashlib.sha256(raw).hexdigest()==bindings['files'][n];records[n]=trace_archive._json(raw)
commit=frozen['source']['commit'];source=producer_source.verify(repo,frozen['source'],reviewed_commit=commit,check_worktree=False)
inputs={'anchor':repo/'benchmarks/motor_optimization/anchor.json','starts':repo/'benchmarks/motor_optimization/harness/starts.json',
        'reference_data':repo/'benchmarks/motor_reference/reference_data.json'}
setup=setup_evidence.check(records,frozen=frozen,inputs=inputs,source=source,git_repo=repo,reviewed_commit=commit)
trace=trace_archive._json(raws[name]);job=created['job'];session=records['session.json']
trace_archive._trace(trace,job,session);study_selection._anchor(trace,setup,frozen)
model=session['models']['L0' if job['method_letter'] in 'DE' else 'L1']
training=next(e['ready']['session']['training'] for e in records['start_preflight.json']['sessions'] if e['space']==job['space'] and e['level']==model['train_level'])
assert trace['evaluator_ready']['session']['training']==training
study_selection._training(trace,model)
mesh_bytes=gzip.decompress((repo/'benchmarks/motor_optimization/final_refinement/smoke/native_binding_L2.msh.gz').read_bytes())
assert hashlib.sha256(mesh_bytes).hexdigest()==frozen['inputs']['validation_mesh']['sha256']
with producer_source.committed_modules(repo,commit,('ledger',)):
 ledger=study_selection._ledger(trace,session,model,importlib.import_module('ledger').Ledger)
starts=trace_archive._json(inputs['starts'].read_bytes())
assert bits(trace['x_start'])==bits(starts['starts'][job['start']][job['space']])
mesh_kinds={};meshes=set()
for row in trace['validations']:
 adapted=setup['definitions'].adapt(trace,row,provenance=setup['provenance'])
 assert adapted['theta0'].key==setup['theta0'][job['space']]['design'].key
 validation_evidence.verify_validation(row,anchor=setup['effective_anchor'],unit_seconds=setup['unit_seconds'],budget_fe=setup['budget_fe'],
                                       **setup['geometry_definitions'][job['space']])
 kind=row.get('mesh',{}).get('kind',row['status']);mesh_kinds[kind]=mesh_kinds.get(kind,0)+1
 if kind=='fresh':meshes.add(row['msh_sha256'])
 for attempt in row.get('attempts',row.get('mesh',{}).get('attempts',[])):
  if attempt.get('msh_sha256'):meshes.add(attempt['msh_sha256'])
print(json.dumps({'status':'PASS','scope':value['scope'],'observed_utc':value['observed_utc'],'job':job['name'],
 'trace_sha256':value['files'][name]['sha256'],'stop_reason':trace['stop_reason'],'validations':len(trace['validations']),
 'ledger_entries':len(trace['ledger']['entries']),'mesh_kinds':mesh_kinds,'generated_meshes_requiring_bytes':sorted(meshes),
 'can_select':False,'can_launch':False},indent=2))
