#!/usr/bin/env bash
set -euo pipefail
export AWS_PROFILE=geode-fem-bench AWS_REGION=us-east-1
TASK_DIR=/Volumes/Stripe/scratch-codex-review/issue1203-main-trace-schema
TASK_SCRIPT_B64=$(base64 < "$TASK_DIR/fetch.py" | tr -d '\n')
/Users/rwalters/GitHub/geode-fem/scripts/aws/geode-worker.sh ssh exp2main "echo $TASK_SCRIPT_B64 | base64 -d | python3 -" > "$TASK_DIR/remote-records.json"
