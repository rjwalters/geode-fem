import json,pathlib,sys
repo=pathlib.Path(sys.argv[1]).resolve();base=pathlib.Path(__file__).resolve().parent
sys.path.insert(0,str(repo/'benchmarks/motor_optimization/final_refinement'))
from capture_archive import load
e=json.loads((base/'roundtrip.json').read_text())
r=load(base/'capture',manifest_sha256=e['manifest_sha256'],git_repo=repo,reviewed_commit=e['reviewed_commit'],capture_tool_commit=e['capture_tool_commit'])
assert r['capture_verified'] and not r['can_select'] and not r['can_launch']
assert len(r['chain']['policy']['jobs'])==100
print(json.dumps({'status':'PASS','scope':e['scope']}))
