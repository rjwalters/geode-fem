from pathlib import Path
import json,sys,os
repo=Path('/Volumes/Stripe/geode-fem/codex-issue-1203-selector')
sys.path.insert(0,str(repo/'benchmarks/motor_optimization/final_refinement'))
import refinement_bundle,refinement_environment
root=Path(__file__).resolve().parent
fixture=Path('/Volumes/Stripe/scratch-codex-review/issue1203-scientific-selection/bundle')
ids=json.loads((fixture/'identities.json').read_text());ids.pop('scope')
prepared=refinement_bundle.prepare(fixture/'capture',git_repo=repo,
 mesh_evidence_commit='df83693b6a7af6badb5a8e18dcd4b27393d17c14',out=root/'inputs',**ids)
(root/'preparation-receipt.json').write_text(json.dumps(prepared,indent=2)+'\n')
executor=Path('/Volumes/Stripe/geode-fem/codex-issue-1203-executor-build')
build=Path('/Volumes/Stripe/scratch-codex-review/issue1203-paired-build-1c6784e7/executors')
args=dict(bundle_root=root/'inputs',bundle_sha256=prepared['sha256'],build_root=build,
 build_sha256='62a4592a4e1a7f53acde1ff7bdd8aacdd7b3650ebdc5b684b62710a93a93baed',
 repo=executor,executor_commit='1c6784e7e1fc8fe0564b1d793a6c4061588028f5')
os.chdir(executor)
receipt=refinement_environment.record(out=root/'environment.json',**args)
(root/'environment-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
proof=refinement_environment.verify(root/'environment.json',sha256=receipt['sha256'],**args)
(root/'verification.json').write_text(json.dumps(proof,indent=2)+'\n')
summary=dict(status='PASS',environment_sha256=receipt['sha256'],
 source_commit=args['executor_commit'],bundle_sha256=prepared['sha256'],
 versions={name:d['version'] for name,d in proof['runtime']['remesher']['distributions'].items()},
 controls=proof['runtime']['controls'],build_processes_stopped=all(p['processes_stopped'] for p in proof['processes']['reports'].values()),
 scope='Real local runtime/build/source/process evidence against synthetic prepared selection; no FEM or native geometry query, no main cohort.',can_launch=False)
(root/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary))
