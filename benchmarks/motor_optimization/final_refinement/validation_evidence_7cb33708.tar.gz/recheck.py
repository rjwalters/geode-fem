import hashlib,json,sys
from dataclasses import asdict
from pathlib import Path
p=Path('/Volumes/Stripe/geode-fem/codex-issue-1203-selector/benchmarks/motor_optimization/final_refinement')
sys.path.insert(0,str(p))
from validation_evidence import verify_validation,adapt_validation
from selection import Design,select
root=Path(__file__).resolve().parent
raw=root/'final-probe/native-schema-probe.json';geo=root/'final-probe/geometry.json'
record=json.loads(raw.read_text());g=json.loads(geo.read_text())
assert record['status']=='PASS'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(geo)==record['geometry_file_sha256']
args=dict(anchor=g['ready']['anchor'],unit_seconds=2.,budget_fe=120.,guard_specs=record['guard_specs'],
 discrete_names=[d['name'] for d in g['geometry']['discrete']])
result=verify_validation(record['validation_record'],**args)
assert result==record['result']
# Context/design is explicitly a synthetic adapter fixture; this does not
# establish a real selected run or complete physical design reconstruction.
context=dict(run_id='native-schema-fixture#0',source_sha256=sha(raw),method='A',space='a',
 start_index=0,repeat=1,eligible_run=True,host_contaminated=False,stop_reason='error')
design=Design.from_values({'native_x':g['ready']['space']['x0']},{'scope':'synthetic provenance context only'})
adapted=adapt_validation(record['validation_record'],context=context,design=design,**args)
selected=select([adapted],f0=args['anchor']['F0'],mean0=args['anchor']['mean0_full_current'],theta0=design)
assert all(c['status']=='unavailable' for c in selected['cells'])
assert selected['records'][0]['rejection_reasons']==['mean_floor_not_met']
summary={'status':'PASS','scope':'Replay retained native values with final adapter; charged time, reconciled context and design binding are synthetic. No main optimization/refinement evidence.',
 'input_sha256':{str(f.relative_to(root)):sha(f) for f in (raw,geo)},
 'source_sha256':{f:sha(p/f) for f in ('validation_evidence.py','geometry_evidence.py','selection.py','test_validation_evidence.py','validation_mutations.py')},
 'result':result,'adapted':asdict(adapted),'selection':selected}
(root/'final-recheck.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({'status':'PASS','rejection_reasons':selected['records'][0]['rejection_reasons']}))
