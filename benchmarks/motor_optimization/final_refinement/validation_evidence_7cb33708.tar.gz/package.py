import hashlib,io,json,re,subprocess,tarfile
from pathlib import Path
repo=Path('/Volumes/Stripe/geode-fem/codex-issue-1203-selector')
h=repo/'benchmarks/motor_optimization/final_refinement';p=Path(__file__).resolve().parent
sha=lambda x:hashlib.sha256(x.read_bytes()).hexdigest()
commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
assert commit=='7cb33708832051099171a135cdc84774662c169e'
mut=json.loads((p/'mutations-with-adapter.json').read_text()); replay=json.loads((p/'final-recheck.json').read_text())
assert all(c['expected_result'] for c in mut['checks']) and replay['status']=='PASS'
for hashes in (mut['source_sha256'],replay['source_sha256']):
 assert all(sha(h/name)==value for name,value in hashes.items())
assert all(sha(p/name)==value for name,value in replay['input_sha256'].items())
files={str(f.relative_to(p)):f for f in p.rglob('*') if f.is_file() and '__pycache__' not in f.parts}
retained=Path('/Volumes/Stripe/scratch-codex-review/issue1206-doctor-training-mesh/native-mixed-a.json')
probe=json.loads((p/'final-probe/native-schema-probe.json').read_text())
assert sha(retained)==probe['retained_native_smoke_sha256']
files['retained-native-mixed-a.json']=retained
inventory={name:sha(f) for name,f in files.items()}
archive=h/'validation_evidence_7cb33708.tar.gz';assert not archive.exists()
with tarfile.open(archive,'w:gz') as tar:
 for name,f in sorted(files.items()):tar.add(f,arcname=name,recursive=False)
 data=(json.dumps(inventory,indent=2)+'\n').encode();info=tarfile.TarInfo('SHA256.json');info.size=len(data);tar.addfile(info,io.BytesIO(data))
with tarfile.open(archive,'r:gz') as tar:
 assert json.load(tar.extractfile('SHA256.json'))==inventory
 for name,value in inventory.items():assert hashlib.sha256(tar.extractfile(name).read()).hexdigest()==value
summary={'schema':1,'status':'PASS','source_commit':commit,
 'scope':'Recorded validation arithmetic/mesh-policy adapter and selector wiring. Not whole-study eligibility or native refinement.',
 'unit_tests':int(re.search(r'Ran (\d+) tests',mut['checks'][0]['stderr']).group(1)),
 'mutations_detected':len(mut['checks'])-1,'mutations':[c['name'] for c in mut['checks'][1:]],
 'source_sha256':mut['source_sha256'],
 'native_schema_replay':{'status':'PASS','retained_smoke_commit':probe['retained_native_source_commit'],
  'retained_smoke_sha256':probe['retained_native_smoke_sha256'],'binary_sha256':probe['binary_sha256'],
  'guard_definitions':len(probe['guard_specs']),'result':'theta0 excluded by mean_floor_not_met',
  'scope':replay['scope'],'new_FEM_solves':0},
 'archive':{'file':archive.name,'sha256':sha(archive),'files':len(files),'each_member_verified':True},
 'limitations':['Reconciled run context and complete bound design are caller obligations.',
  'Raw source/runtime/anchor/mesh-file provenance and recovery-chain closure remain pending integration.',
  'Geometry margin arithmetic is verified; actual geometry is not reconstructed from coordinates by this module.',
  'Native replay uses retained values; its charged stamp and context/design binding are synthetic.',
  'Native refinement and independent review remain pending.']}
(h/'validation-evidence-checks.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({k:summary[k] for k in ('unit_tests','mutations_detected','archive')}))
