import hashlib,json,sys
from pathlib import Path
h=Path('/Volumes/Stripe/geode-fem/codex-issue-1202/benchmarks/motor_optimization/harness')
p=Path('/Volumes/Stripe/geode-fem/codex-issue-1203-selector/benchmarks/motor_optimization/final_refinement')
sys.path[:0]=[str(p),str(h)]
from evaluator import Evaluator,to_bits
from run import thread_env
from validation_evidence import verify_validation
root=h.parents[2]
out=Path(__file__).resolve().parent
old=Path('/Volumes/Stripe/scratch-codex-review/issue1206-doctor-training-mesh/native-mixed-a.json')
smoke=json.loads(old.read_text());assert smoke['status']=='PASS'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
binary=root/'target/build-pr-head-848fa480/icem_harness_eval'
assert sha(binary)==smoke['binary_sha256']
command=smoke['command'].copy(); command[command.index('--mesh-out')+1]=str(out/'geometry-only.meshes')
ev=Evaluator(command,env=thread_env(),timeout=30,stderr_path=out/'geometry.stderr')
try:
 assert ev.ready['space']==smoke['ready']['space']
 g=ev.request('geometry',timeout=30,x_bits=to_bits(ev.ready['space']['x0']))['geometry']
finally: ev.close()
(out/'geometry.json').write_text(json.dumps({'ready':ev.ready,'geometry':g,'resources':ev.resources()},indent=2)+'\n')
raw=smoke['validate']
# Project the retained native reply through the production driver's recorded
# field names. The charged stamp here is synthetic, not a measured optimizer time.
r={key:raw[key] for key in ('status','F_val','mean_full','stds','fractions','means','mesh','msh_sha256')}
r.update(index=0,seconds=40.,wall_fe=20.,credited=True,
 min_h=g['min_h'],h_nonnegative=g['admissible'],geometry={
 'buildable':g['buildable'],'admissible':g['admissible'],'credit_admissible':g['credit_admissible'],
 'construction_error':g['construction_error'],
 'guards':[{k:gd[k] for k in ('name','unit','margin','scale','c','h','pass')} for gd in g['guards']],
 'discrete':[{'name':gd['name'],'pass':gd['pass']} for gd in g['discrete']]})
a=raw['acceptance'];r.update({k:a[k] for k in ('admissible','mean_ok','delta_F','F_upper','mean_floor')})
r['attained']={t['name']:t['attained'] for t in a['targets']}
specs={gd['name']:{k:gd[k] for k in ('scale','unit','strict')} for gd in g['guards']}
result=verify_validation(r,anchor=ev.ready['anchor'],unit_seconds=2.,budget_fe=120.,guard_specs=specs,
 discrete_names=[d['name'] for d in g['discrete']])
assert result['mesh_pass'] and result['completed'] and not any(result['target_credit'].values())
record={'status':'PASS','scope':'Retained native theta0 validation plus fresh zero-FEM geometry query; synthetic charged stamp. No optimizer/main result.',
 'retained_native_smoke_sha256':sha(old),'retained_native_source_commit':smoke['base_commit'],
 'binary_sha256':sha(binary),'source_sha256':{x.name:sha(x) for x in (p/'validation_evidence.py',p/'geometry_evidence.py',p/'test_validation_evidence.py')},
 'geometry_file_sha256':sha(out/'geometry.json'),'guard_specs':specs,'validation_record':r,'result':result}
(out/'native-schema-probe.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'status':'PASS','guards':len(specs),'target_credit':result['target_credit'],'scope':record['scope']}))
